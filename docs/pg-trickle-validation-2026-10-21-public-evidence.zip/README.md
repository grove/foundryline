# Selected public validation evidence

Decision: NO CLEAR BENEFIT in this pilot.
Action: KEEP FOUNDRYLINE UNCHANGED.

This is a curated publication derivative of the completed experiment, not a new run. The reviewed/public filenames requested for publication were not found; this subset was prepared from the preserved original report and private raw archive. The original raw archive is not published.

The adjacent public JSON index binds this ZIP and every member by SHA256. Each selected member identifies its original archive member and original SHA256. Excerpts are explicitly labeled. Machine-local paths use $WORKSPACE, $FOUNDRYLINE, $LOCAL_PATH and $HOMEBREW placeholders; these are publication substitutions, not runnable commands. ANSI formatting is removed. Original bytes and complete logs remain private. The four final patches and candidate tree identities are unchanged.

records/ contains worker self-test metadata, selected logs and handoffs. assessment/ contains separate assessor checks and baseline/candidate results; assessment_1177.rs is the final independent Testcontainers assessment. Baseline failures and the generic static check's baseline pass are retained. Unit logs are excerpts, not full suite logs. Handoffs name some files omitted from this selected subset; consult the index for what is actually published. Earlier harness/fixture/environment failures are described in the preserved handoffs and harness-corrections.md, not reclassified as product failures.

native/ contains field excerpts of EXECUTION UNAVAILABLE reports only. Paths were substituted, so these are not intact or independently replayable Proofline records. No canary or selected native command executed. Checksums prove the public copies' integrity, not receipt authenticity, coverage completeness or complete correctness.

learn/ contains primary-source field/log excerpts for the retrospective, frozen at the experiment's inspection time. The Learn handoff records the historical decision already made, not a new production/customer outcome. Profiles, private/local environment inventories, complete process lists, unrelated source, duplicated native product snapshots, binaries and build caches are omitted.

This publication changes documentation only. Candidate patches are inert evidence, not adopted pg-trickle changes. No new runner, schema, tool, workflow or mandatory process is introduced. Full-project and real pg_tide verification, reliable total overhead/tokens/costs, enforced independent-host isolation and production/customer attribution remain unavailable or unestablished.
