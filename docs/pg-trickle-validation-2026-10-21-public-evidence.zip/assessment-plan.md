# Independent assessment plan

Frozen 2026-10-21 before reading any worker candidate. Baseline: 0cbd84dce4fede39fa36f2c8716e0faa0a9b1b14, tree 05ee73d25ae6d10adcd4788a2826525d30eb8085. Workers receive only the original issue and their normal/Deliver instruction, not this plan or checks. Four attempts only; no evaluator repair of their candidates.

## A — issue 1179

Source: src/api/outbox.rs helper and attach_outbox_impl caller; issue's 46 ASCII a + 6 é reproducer. Execute the actual extracted helper using the actual cached xxhash-rust 0.8.18 dependency, with no PostgreSQL FFI. This is a narrow supplemental check, not full project or SQL-path evidence.

- Negative: reproducer must not panic; valid identifier inputs with 2/3/4-byte Unicode crossing byte 54 must return valid UTF-8 of at most 63 bytes. Exercise mixed prefixes and legal input lengths up to 63 bytes.
- Compatibility: exact short ASCII, empty helper input, short Unicode, 56-byte threshold, and unchanged long ASCII output/hash algorithm. Hash full original input with original seed and first eight hex digits.
- Collision control: pairs sharing the retained prefix but differing after it must remain distinct for tested values. This preserves the existing probabilistic protection, not a claim of mathematical uniqueness for a 32-bit suffix.
- Project evidence: inspect actual worker fmt/lint/unit/E2E receipts; do not promote compilation/dependency failures to product failures. SQL attach reachability remains unavailable unless actually run with a source-identified pg_tide dependency.

## B — issue 1177

Source: src/lib.rs schema revocation; src/api/output_delta.rs ensure_payload, authorized_stream, registration, batch/ack APIs; SQL_REFERENCE typed payload contract; existing v104/v108 conformance, CDC and schema tests. Prepare a separate regression using the existing E2eDb Testcontainers harness and fresh extension installation, never local PG. Baseline must show the reported schema-USAGE denial before attributing a runtime fix.

- Positive: non-superuser/NOBYPASSRLS stream owner, only explicit API EXECUTE + ordinary source privileges, no manually supplied changes-schema USAGE, registers/re-registers, activates a consumer, produces EXACT output, reads returned payload as itself, verifies contents and acknowledgment.
- Negative: owner cannot read source CDC/change buffers or another owner's payload; unrelated role cannot read payload/private buffers, register for the stream, use its consumer APIs, CREATE in private schema, or inherit PUBLIC grants. Role names requiring SQL identifier quoting. Capture SQLSTATE where possible.
- Compatibility: repeat registration idempotence, schema isolation across two independently owned streams, standard superuser path, resnapshot/EXACT/ack rollback behavior in original v104/v108 suites. Changed grants must remain scoped to the intended owner and payload, without ALL TABLES/PUBLIC grants or private-schema CREATE.
- Run original relevant Testcontainers suites on exact built artifacts when available. If a required dependency/tool/build is unavailable, retain checks as NOT RUN/UNAVAILABLE. Source reasoning may support a candidate but cannot establish DB security behavior.

## Comparison rules

Same baseline, tools, medium reasoning and 20-minute worker budget. Fresh fork-none workers; no feedback of counterpart/evaluator results. Three-slot scheduling causes wall-time/cache contention; report it. Record actual worker starts/ends, interventions and unavailable model/cost identity. Report selected-check results separately from delivery correctness; no inference from a green summary. Root setup and separate evaluation time are shared costs, not silently attributed to either arm. Additional Foundryline activity is whatever the published recipe causes the worker to do, with no optional tool chain imposed.

## Learn

Read original PR1197 and comments/reviews, exact premerge CI, postmerge run39397208394 full job list and failing job118624985581 logs, issue1198 and PR1199. Distinguish author claims from primary CI observations, premerge from postmerge, merge from deployed revision and customer impact. Reconstruct the actual recorded engineering decision, recommend only a bounded next observation; no implementation or tracker changes. Unknown deployment/business targets remain UNKNOWN / NO APPROVED OUTCOME TARGET.
