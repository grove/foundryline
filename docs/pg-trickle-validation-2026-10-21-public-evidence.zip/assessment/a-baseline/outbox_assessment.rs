pub(crate) fn outbox_table_name_for(st_name: &str) -> String {
    let raw = format!("outbox_{}", st_name);
    // PostgreSQL identifier limit is 63 bytes.
    if raw.len() <= 63 {
        raw
    } else {
        // SEC-5: Use xxh64 hash suffix to avoid name collisions on truncation.
        const SEED: u64 = 0x517cc1b727220a95;
        let hash = xxhash_rust::xxh64::xxh64(st_name.as_bytes(), SEED);
        let suffix = &format!("{:016x}", hash)[..8];
        format!("{}_{}", &raw[..54], suffix)
    }
}

#[test]
fn original_reported_reproducer() {
    let input = format!("{}{}", "a".repeat(46), "é".repeat(6));
    assert_eq!(input.len(), 58);
    let result = outbox_table_name_for(&input);
    assert!(result.len() <= 63);
    assert!(std::str::from_utf8(result.as_bytes()).is_ok());
}

#[test]
fn unicode_boundaries_and_byte_budget() {
    let mut count = 0;
    for symbol in ["é", "€", "😀"] {
        for prefix in 0..=63 {
            for repeated in 1..=32 {
                let input = format!("{}{}", "a".repeat(prefix), symbol.repeat(repeated));
                if input.len() > 63 { continue; }
                let raw = format!("outbox_{input}");
                let result = outbox_table_name_for(&input);
                assert!(result.len() <= 63, "{input:?} gave {} bytes", result.len());
                if raw.len() <= 63 {
                    assert_eq!(result, raw);
                } else {
                    let mut boundary = 54;
                    while !raw.is_char_boundary(boundary) { boundary -= 1; }
                    let hash = xxhash_rust::xxh64::xxh64(input.as_bytes(), 0x517cc1b727220a95);
                    assert_eq!(result, format!("{}_{:08x}", &raw[..boundary], hash >> 32));
                }
                count += 1;
            }
        }
    }
    println!("checked {count} valid multibyte identifiers");
}

#[test]
fn existing_ascii_and_short_behavior() {
    for input in ["", "orders", "a\"b", "é😀€"] {
        assert_eq!(outbox_table_name_for(input), format!("outbox_{input}"));
    }
    for length in 0..=63 {
        let input = "a".repeat(length);
        let raw = format!("outbox_{input}");
        let expected = if raw.len() <= 63 { raw } else {
            let hash = xxhash_rust::xxh64::xxh64(input.as_bytes(), 0x517cc1b727220a95);
            format!("{}_{:08x}", &raw[..54], hash >> 32)
        };
        assert_eq!(outbox_table_name_for(&input), expected);
    }
}

#[test]
fn common_prefix_retains_full_input_hash() {
    for prefix in ["a".repeat(55), format!("{}{}", "a".repeat(46), "é".repeat(5))] {
        let first = format!("{prefix}x");
        let second = format!("{prefix}y");
        assert_ne!(outbox_table_name_for(&first), outbox_table_name_for(&second));
        assert_eq!(outbox_table_name_for(&first), outbox_table_name_for(&first));
    }
}
