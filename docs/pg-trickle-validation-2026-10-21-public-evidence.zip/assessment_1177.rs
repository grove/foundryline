//! Independent source-grounded assessment; copy into tests only in an assessment checkout.
mod e2e;
#[allow(dead_code)]
#[path = "conformance/reference_clients.rs"]
mod reference_clients;

use e2e::E2eDb;
use sqlx::{Connection, Row};

async fn denied(connection: &mut sqlx::PgConnection, statement: String) {
    let error = sqlx::query(sqlx::AssertSqlSafe(statement.clone()))
        .execute(connection)
        .await
        .expect_err(&format!("must deny {statement}"));
    let code = error
        .as_database_error()
        .and_then(|e| e.code())
        .map(|c| c.into_owned());
    assert_eq!(
        code.as_deref(),
        Some("42501"),
        "wrong denial for {statement}: {error}"
    );
}

#[tokio::test]
async fn independent_1177_payload_access_and_private_table_isolation() {
    let db = E2eDb::new().await.with_extension().await;
    sqlx::raw_sql(r#"
        CREATE ROLE "validation owner""1177" NOSUPERUSER NOBYPASSRLS NOLOGIN;
        CREATE ROLE validation_other1177 NOSUPERUSER NOBYPASSRLS NOLOGIN;
        CREATE ROLE validation_outsider1177 NOSUPERUSER NOBYPASSRLS NOLOGIN;
        CREATE SCHEMA validation1177;
        GRANT USAGE ON SCHEMA validation1177, pgtrickle
          TO "validation owner""1177", validation_other1177, validation_outsider1177;
        CREATE TABLE validation1177.source (id int PRIMARY KEY, value text);
        INSERT INTO validation1177.source VALUES (1, 'baseline');
        GRANT SELECT, MAINTAIN ON validation1177.source TO "validation owner""1177", validation_other1177;
        SELECT pgtrickle.create_stream_table(
          name => 'validation1177.first',
          query => 'SELECT id, value FROM validation1177.source',
          schedule => '1h', refresh_mode => 'DIFFERENTIAL', initialize => false,
          orchestration_mode => 'EXTERNAL');
        SELECT pgtrickle.create_stream_table(
          name => 'validation1177.second',
          query => 'SELECT id, value FROM validation1177.source',
          schedule => '1h', refresh_mode => 'DIFFERENTIAL', initialize => false,
          orchestration_mode => 'EXTERNAL');
        ALTER TABLE validation1177.first OWNER TO "validation owner""1177";
        ALTER TABLE validation1177.second OWNER TO validation_other1177;
        DO $grants$
        DECLARE f regprocedure;
        BEGIN
          FOR f IN SELECT oid::regprocedure FROM pg_proc
            WHERE pronamespace = 'pgtrickle'::regnamespace AND proname IN (
              'register_output_delta_consumer', 'begin_output_delta_resnapshot',
              'ack_output_delta_resnapshot', 'output_delta_batches', 'ack_output_delta')
          LOOP
            EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO "validation owner""1177", validation_other1177, validation_outsider1177', f);
          END LOOP;
        END $grants$;
    "#).execute(&db.pool).await.expect("fresh role/source/stream setup");

    for root in ["validation1177.first", "validation1177.second"] {
        let graph = reference_clients::graph_digest(&db.pool, root).await;
        reference_clients::refresh_graph(&db.pool, root, &graph).await;
    }
    let digest = reference_clients::stream_contract_digest(&db.pool, "validation1177.first").await;
    let other_digest =
        reference_clients::stream_contract_digest(&db.pool, "validation1177.second").await;
    let mut owner = db.pool.acquire().await.expect("dedicated owner connection");
    sqlx::query(r#"SET ROLE "validation owner""1177""#)
        .execute(&mut *owner)
        .await
        .unwrap();
    let grants: (bool, bool) = sqlx::query_as("SELECT has_schema_privilege(current_user, 'pgtrickle_changes', 'USAGE'), has_schema_privilege(current_user, 'pgtrickle_changes', 'CREATE')")
        .fetch_one(&mut *owner).await.unwrap();
    assert_eq!(
        grants,
        (false, false),
        "fresh owner must not be pre-granted private schema access"
    );
    let registration = sqlx::query("SELECT consumer_id::text AS id, delta_relation FROM pgtrickle.register_output_delta_consumer('validation1177.first'::regclass, 'independent', $1, 'RESNAPSHOT_REQUIRED')")
        .bind(&digest).fetch_one(&mut *owner).await.expect("owner registration");
    let consumer: String = registration.get("id");
    let relation: String = registration.get("delta_relation");
    let repeated: String = sqlx::query_scalar("SELECT consumer_id::text FROM pgtrickle.register_output_delta_consumer('validation1177.first'::regclass, 'independent', $1, 'RESNAPSHOT_REQUIRED')")
        .bind(&digest).fetch_one(&mut *owner).await.expect("idempotent registration");
    assert_eq!(consumer, repeated);
    let mut tx = owner.begin().await.unwrap();
    let (token, _) = reference_clients::begin_resnapshot(&mut *tx, &consumer).await;
    assert_eq!(
        reference_clients::ack_resnapshot(&mut *tx, &consumer, &token).await,
        "ACTIVE"
    );
    tx.commit().await.unwrap();

    db.execute("INSERT INTO validation1177.source VALUES (2, 'exact payload')")
        .await;
    let graph = reference_clients::graph_digest(&db.pool, "validation1177.first").await;
    reference_clients::refresh_graph_without_full(&db.pool, "validation1177.first", &graph).await;
    let batch = reference_clients::pending_batch(&mut *owner, &consumer).await;
    assert_eq!(batch.mode, "EXACT");
    assert_eq!(batch.row_count, 1);
    let rows: Vec<(i32, String, String)> = sqlx::query_as(sqlx::AssertSqlSafe(format!(
        "SELECT id, value, action FROM {relation} WHERE batch_token = {} ORDER BY ordinal",
        batch.batch_token
    )))
    .fetch_all(&mut *owner)
    .await
    .expect("returned payload must be readable as owner");
    assert_eq!(rows, vec![(2, "exact payload".into(), "INSERT".into())]);
    let mut tx = owner.begin().await.unwrap();
    assert_eq!(
        reference_clients::ack(&mut *tx, &consumer, batch.batch_token).await,
        "APPLIED"
    );
    tx.rollback().await.unwrap();
    assert_eq!(
        reference_clients::pending_batch(&mut *owner, &consumer)
            .await
            .batch_token,
        batch.batch_token
    );
    assert_eq!(
        reference_clients::ack(&mut *owner, &consumer, batch.batch_token).await,
        "APPLIED"
    );
    denied(
        &mut owner,
        "CREATE TABLE pgtrickle_changes.invalid_injection (id int)".into(),
    )
    .await;

    let buffers: Vec<String> = sqlx::query_scalar("SELECT quote_ident(n.nspname)||'.'||quote_ident(c.relname) FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='pgtrickle_changes' AND c.relkind IN ('r','p') AND c.relname NOT LIKE 'output_delta_%'")
        .fetch_all(&db.pool).await.unwrap();
    assert!(
        !buffers.is_empty(),
        "must actually test private CDC buffers"
    );
    for buffer in &buffers {
        denied(&mut owner, format!("SELECT * FROM {buffer} LIMIT 1")).await;
    }
    sqlx::query("RESET ROLE")
        .execute(&mut *owner)
        .await
        .unwrap();
    sqlx::query("SET ROLE validation_other1177")
        .execute(&mut *owner)
        .await
        .unwrap();
    let other: String = sqlx::query_scalar("SELECT delta_relation FROM pgtrickle.register_output_delta_consumer('validation1177.second'::regclass, 'independent-other', $1, 'RESNAPSHOT_REQUIRED')")
        .bind(other_digest).fetch_one(&mut *owner).await.expect("second owner registration");
    denied(&mut owner, format!("SELECT * FROM {relation} LIMIT 1")).await;
    sqlx::query("RESET ROLE")
        .execute(&mut *owner)
        .await
        .unwrap();
    sqlx::query(r#"SET ROLE "validation owner""1177""#)
        .execute(&mut *owner)
        .await
        .unwrap();
    denied(&mut owner, format!("SELECT * FROM {other} LIMIT 1")).await;
    sqlx::query("RESET ROLE")
        .execute(&mut *owner)
        .await
        .unwrap();
    sqlx::query("SET ROLE validation_outsider1177")
        .execute(&mut *owner)
        .await
        .unwrap();
    denied(&mut owner, format!("SELECT * FROM {relation} LIMIT 1")).await;
    for buffer in &buffers {
        denied(&mut owner, format!("SELECT * FROM {buffer} LIMIT 1")).await;
    }
    denied(
        &mut owner,
        "CREATE TABLE pgtrickle_changes.invalid_injection (id int)".into(),
    )
    .await;
    let error = sqlx::query("SELECT * FROM pgtrickle.register_output_delta_consumer('validation1177.first'::regclass, 'intruder', $1, 'RESNAPSHOT_REQUIRED')")
        .bind(digest).fetch_all(&mut *owner).await.expect_err("unrelated role cannot register");
    assert!(
        error.to_string().contains("PGT_EXT_AUTHORIZATION"),
        "{error}"
    );
    let error = sqlx::query("SELECT * FROM pgtrickle.output_delta_batches($1::uuid, NULL)")
        .bind(consumer)
        .fetch_all(&mut *owner)
        .await
        .expect_err("unrelated role cannot use consumer");
    assert!(
        error.to_string().contains("PGT_EXT_AUTHORIZATION"),
        "{error}"
    );
    sqlx::query("RESET ROLE")
        .execute(&mut *owner)
        .await
        .unwrap();
}
