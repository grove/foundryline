# Deliver attempt A — issue #1179

Implemented locally; no publication, product commit, branch, push, PR, remote workflow, merge, or deployment. One coding-agent attempt; no subagents or human intervention. The recipe creates a synthetic commit only inside its private frozen copy; product HEAD remains the original detached baseline.

Original complete issue and metadata: original-source.json, SHA256 6482de23a6d55cc7152811f5f2bae7ec9270571ee4356fb7160c7a9e3ed9681e. No comments exist. Followed AGENTS.md, RTK.md, Ponytail full, relevant Architecture/SQL Reference/INSTALL material and published patterns/deliver.md. Direct original-request path; optional Intentline acceptance/export skipped.

## Candidate

- Product: $WORKSPACE/a-deliver
- Clean detached baseline: 0cbd84dce4fede39fa36f2c8716e0faa0a9b1b14
- Final implementation: src/api/outbox.rs only; stop implementation writes after 2026-10-21T16:33:46Z. Later writes are ignored generated build files and external evidence only.
- Final patch: candidate.patch; SHA256 b100723b5298bef152e49dcb28945406c8246f354722dc9426d04b383dc29f41
- All relevant unstaged/staged/nonignored untracked included: only one tracked file modified, actual index unchanged, no nonignored untracked files. final-status.txt retained.
- Proofline frozen candidate tree: 9bf65bc54ff336fc858cd4144a9c7ba2a187e13a; source file bytes matched live product at freeze and final verification.
- Frozen source SHA256: c4bd505d49011d9228e0427ba288d77003644a515df455a7bd2700646c60ee92; see candidate-identity.json.

The shared helper retreats from byte 54 until a valid UTF-8 character boundary, retaining the existing full-input xxh64 seed and eight-hex-digit suffix. ASCII and short-name paths keep their existing outputs. Its only production caller is attach_outbox_impl; no caller signature, fixtures, configuration, SQL API exports, authorization, or outbox transaction changes.

## Behavior and negative cases

| Original obligation / preserved behavior | Evidence |
| --- | --- |
| No panic for 46 ASCII a followed by six é | Regression includes this exact input; passed in full unit suite and focused extracted-helper check |
| Valid UTF-8 name at most 63 bytes | Rust String result plus byte-length assertion across 2/3/4-byte character cases at crossing/aligned offsets |
| Retain collision protection | Eight hexadecimal suffix chars, deterministic result and different result for same prefix with changed tail; existing hash algorithm unchanged |
| Preserve short/ASCII/empty names and exact boundary | Existing tests plus real Unicode name with prefixed length exactly 63 bytes; all pass |
| Reachability through attach_outbox with supported pg_tide | Only production call inspected; SQL-facing execution NOT RUN / NOT DEMONSTRATED |

The new regression was checked against the unchanged baseline helper in an external temporary Rust harness linked to the xxhash dependency built in this checkout. Candidate: six tests passed. Baseline: five passed and regression failed with byte index 54 inside é (bytes 53..55). No baseline product files were edited. See compare_baseline.py, baseline-comparison.log, candidate-naming-test.log, baseline-naming-test.log. This is ordinary authorized evidence, not native Proofline evidence.

## Actual verification

- just fmt: exit 0. Final run 20.71s.
- env PATH=$HOMEBREW/bin:/usr/bin:/bin:/usr/sbin:/sbin CARGO_NET_OFFLINE=true just lint: exit 0, zero warnings, all constituent checks passed; 94.67s.
- Same environment just test-unit: exit 0, 2615 passed, zero failed/ignored; 281.54s total including build/lock wait; test execution 3.83s.
- External exact-helper/baseline comparison: wrapper exit 0; candidate test binary 0, baseline test binary expected 101 with original UTF-8 panic; 2.36s.
- git diff --check: exit 0. Final patch/hash/source/untracked assertions: passed.
- Earlier ordinary lint/unit invocations failed (exit 101) because system Python3.9 cannot parse repository generator type annotation str | None. Retained in lint.log, unit.log and native-lint-offline.log. Selecting existing Homebrew Python3.15 resolved the environment prerequisite; no new tools installed.

Exact argv, cwd, start/end UTC, elapsed seconds, exit codes and combined stdout/stderr for recorded commands are stored in matching .json/.log files; verification-summary.json indexes final checks. First inspection/edit setup commands predated the recorder; they remain in the agent tool transcript, not duplicated here. This limitation is explicit in inspection-notes.md.

## Proofline result — EXECUTION UNAVAILABLE

Tool pin verified: 8e117fff4de2459637fe7f74f47ab17fc3341d84. Darwin arm64 host; Python3.15.0. Installed codex-cli 0.163.0. Required exact Codex0.162.1 unavailable; native canary boundary and selected test never executed. No restriction changes or unprotected fallback claimed as Proofline evidence.

Selected native argv: ["$HOMEBREW/bin/just", "test-unit"]. Original source is the complete issue JSON. Zero model dispatches.

- proofline-native/report.json: actual snapshot refusal, "Working tree changed during snapshot; pause edits and retry". Unit runner had generated nonignored .cargo-target. Preserved generated artifacts outside product, without changing source.
- proofline-frozen/report.json: subsequent frozen snapshot succeeds, then actual "This boundary requires Codex CLI 0.162.1; no model authentication is used". Exit 2, 4.63s wall time.
- status readback: EXECUTION UNAVAILABLE, exit 2, retained proofline-status.log.
- status --show-source: exit 1, "--show-source requires an intact frozen check-only record" because execution stopped before protected snapshot sealing; retained proofline-readback.log. Original source bytes independently retained and hashed.
- Both complete report/evidence JSON files preserved; no native command receipts exist because no protected command executed.

All obligations remain NOT DEMONSTRATED by native Proofline. Coverage completeness UNKNOWN. Passing ordinary tests does not certify full SQL/runtime behavior or supported pg_tide integration.

## Time, setup, and handoff

First tool-action UTC was not sampled; conservative approximate budget start 2026-10-21T16:31:05Z, first measured UTC sample 2026-10-21T16:32:35Z. Handoff end UTC 2026-10-21T16:41:10.650234+00:00. Completed within 20 minutes of conservative start. Do not treat approximate start as an exact measured timestamp.

No human intervention/coaching after initial task. Able to follow published direct recipe through implementation, candidate snapshot, actual refusal, status readback and review handoff. Native execution could not complete on installed CLI. Additional ceremony/setup: private recording wrapper, Python PATH selection, generated build-directory relocation, two Proofline check invocations and hash capture. No new infrastructure installed. Docker inventory only; images were not treated as candidate evidence or inspected for unrelated source. SQL attachment/full E2E checks not run because the pure helper regression is covered and a matching rebuilt candidate/pg_tide runtime was not prepared. Docker availability itself was confirmed; this is not a claim Docker was unavailable.

See inspection-notes.md for incidental process-list output and initial recorder limits. No sibling source/results/evaluator material was opened or used.

Review-only staging/commit commands (not executed):

```sh
cd $WORKSPACE/a-deliver
git add -- src/api/outbox.rs
git commit -m "Fix UTF-8 truncation in derived outbox names"
```

Skipped optional Intentline planning, SQL attachment runtime/E2E execution, new dependencies, publication and broader unrelated changes. Remaining risk: SQL integration is unverified here and native Proofline execution is unavailable on the installed CLI version.
