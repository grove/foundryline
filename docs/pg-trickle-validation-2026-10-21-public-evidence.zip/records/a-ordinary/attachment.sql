\set ON_ERROR_STOP on
CREATE EXTENSION pg_tide VERSION '0.53.0';
CREATE TABLE issue1179_source(id integer PRIMARY KEY, val text);
INSERT INTO issue1179_source VALUES (1, 'value');
DO $check$
DECLARE
    base text := repeat('a',46) || repeat('é',6);
    name text;
    outboxes text[];
BEGIN
    FOREACH name IN ARRAY ARRAY[base, base || 'b'] LOOP
        PERFORM pgtrickle.create_stream_table(name, 'SELECT id, val FROM issue1179_source', '1m', 'DIFFERENTIAL');
        PERFORM pgtrickle.attach_outbox(name);
    END LOOP;
    SELECT array_agg(tide_outbox_name) INTO outboxes FROM pgtrickle.pgt_outbox_config;
    ASSERT array_length(outboxes,1) = 2, 'both attachments must be recorded';
    ASSERT outboxes[1] <> outboxes[2], 'truncated names must remain distinct';
    ASSERT octet_length(outboxes[1]) <= 63 AND octet_length(outboxes[2]) <= 63, 'identifier byte limit';
    ASSERT (SELECT count(*) FROM tide.tide_outbox_config) = 2, 'both external outboxes must exist';
END
$check$;
SELECT tide_outbox_name, octet_length(tide_outbox_name) AS bytes FROM pgtrickle.pgt_outbox_config ORDER BY tide_outbox_name;
