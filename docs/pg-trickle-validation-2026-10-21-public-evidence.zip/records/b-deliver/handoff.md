# Deliver attempt — pg-trickle #1177

Implemented a scoped schema USAGE grant for the output-delta consumer owner beside the existing typed-table SELECT grant. Documented it and added a real non-superuser regression in the existing v108 conformance suite. No broad table grant or PUBLIC grant.

Original complete source: original-issue-1177.json, SHA256 1fa7b5c687e8744f8ec81ea91e5fdbb3c09e1796834d1a7b2684e84011e110b6. Zero issue comments. See admission.md and requirements.md for authorization, scope, and negative cases.

UTC start: 2026-10-21T16:41:38Z. UTC end: 2026-10-21T16:50:02.273250+00:00. Budget 20 minutes; one fresh attempt; no subagents. Baseline 0cbd84dce4fede39fa36f2c8716e0faa0a9b1b14, clean detached checkout at entry. Product writes stopped after correcting one test API grant and formatting at 16:48:31 UTC; final freeze 2026-10-21T16:48:47.488076+00:00. No subsequent candidate changes; final-integrity check and patch hash reconfirmed.

Final candidate: candidate.patch, SHA256 cd8dd695ec9ebee965c918818614fef0bee0a0248c85dd3e773291acbb4207a3, including all changes; no nonignored untracked files. Proofline isolated snapshot tree f4131b0e8651518f06de2d34ea39d44bcd1e0b49, snapshot commit a0d73409302147f1e37debe71b1b739a08ef1cd3. Tool-generated isolated snapshot identities are not product-repository commits; no product commit, staging, branch, push, PR, remote write, workflow run or deployment occurred. Initial frozen candidate/patch are retained separately as candidate-initial.*; native-final refers to that historical version. native-corrected is the final version.

## Actual verification

- fmt-corrected: `just fmt`, exit 0, 3.74 seconds.
- lint-corrected: `env PATH=$HOMEBREW/opt/python@3.14/libexec/bin:$HOMEBREW/bin:/usr/bin:/bin:/usr/sbin:/sbin just lint`, exit 0, 8.57 seconds; formatting check, clippy all targets with warnings denied, security-definer, privilege-boundary, docs, SQL-builder, fuzz inventory and monitoring checks passed.
- build: published tests/build_e2e_image.sh from this checkout and existing builder image, exit 0, 220.42 seconds. Build receipts show COPY src and package compilation. Runtime image sha256:f6efbc7791082c45697c1b2457851ed34f4e6729f861a08a207ae334c7670681 (linux/amd64) tagged pg_trickle_b_deliver_1177:local using exact built image ID. See build.log, tag-image.*, candidate-image.*. Product Rust source did not change after this build.
- e2e-corrected: existing scripts/run_v108_conformance.sh with PGT_DISABLE_NEXTEST=1, PGS_E2E_IMAGE=pg_trickle_b_deliver_1177:local and Python3.14 PATH, selecting e2e_v108_conformance_tests; exit 0, 14.44 seconds. All 20 tests passed. New regression created non-superuser owner via public create API, asserted schema USAGE absent before registration, registered/activated through public APIs, generated EXACT batch and read exact typed payload as owner, then received SQLSTATE 42501 for its source buffer, unrelated source buffer and private catalog.
- final-integrity: `git diff --check`, exit 0. Final patch SHA256/no untracked files reconfirmed separately.

Each durable checker invocation has `<name>.json` (exact argv, cwd, UTC start/end, elapsed seconds, exit code) and `<name>.log` (full stdout/stderr). Earlier failures remain retained: initial lint hit Python3.9 unsupported annotation syntax; initial Proofline interpreter lacked tomllib; e2e started while Docker build was pending (missing candidate image, no behavioral result); first built-image run was 19 passed/1 failed because my test grant specified oid rather than public regclass SQL signature. Corrected only that test grant. A progress-only docker top probe had no container argument and exited 1. No failures were deleted or reclassified as product bugs.

## Native Proofline evidence and limitations

Pinned full checkout: 8e117fff4de2459637fe7f74f47ab17fc3341d84. Host Darwin arm64; installed codex-cli 0.163.0. Native-corrected check and status both exited 2: EXECUTION UNAVAILABLE, requires exact Codex CLI 0.162.1. Complete report and version receipt retained in native-corrected/report.json. It selected only `$HOMEBREW/bin/python3.14 -B scripts/check_privilege_boundaries.py`, but executed no selected checks, dispatched no models, and never reached native canary preflight. No native check success is claimed. `status --show-source` on earlier unavailable record was rejected; plain status was inspected. Ordinary project checks above were separately authorized; they are not native Proofline fallback evidence. R1/R2 NOT DEMONSTRATED by native checks; coverage completeness UNKNOWN. Original bytes were retained in native source snapshot and copied here.

Full repository test-all, ignored/other E2E suites, upgrade/ownership lifecycle and alternate role memberships were not run. Selected runtime regression and v108 compatibility tests passed; independent review still required. No monetary/model cost measured; wall times are actual tool receipts. No native isolation qualification or complete obligation coverage claim.

## Setup, interventions and recipe use

Used Ponytail full skill and Deliver direct original-source route. Optional Intentline acceptance/export was skipped for this small issue; no skill installation or infrastructure installation. Extra ceremony: private command logger/evidence directory; native candidate snapshots/check/status; selecting existing Python3.14 for build generator compatibility; own-source Docker rebuild and unique local tag; candidate patch hashes and handoff. Published Docker script hardcodes pg_trickle_e2e:latest, ignoring IMAGE_NAME override, so it temporarily replaced that shared local tag; coordinator was notified and confirmed its own builds use separate tags. Final tests used unique exact-identity tag.

No human debugging or implementation intervention; coordinator supplied task/checkout/pin/source and confirmed avoiding shared tag. No coaching was needed to follow recipe. Native execution could not complete on the installed version; restrictions were not weakened and no new infrastructure installed. Docker commands used authorized host escalation; no escalation refusal occurred. Image inventory incidentally displayed a sibling image name; it was not inspected/used. No sibling attempts, fixes/history beyond baseline, evaluator material or results were read.

Initial read-only discovery commands predated durable logger; exact outputs and tool timing remain in the agent tool transcript, summarized in admission.md, rather than duplicated in this directory. This is an evidence-capture limitation. All implementation-verification commands and failures after logger setup have durable raw receipts.

Review commands are in commands-for-review.sh and were NOT executed:

```sh
git add src/api/output_delta.rs tests/e2e_v108_conformance_tests.rs docs/SQL_REFERENCE.md
git commit -m "Fix schema access for output-delta consumer owners"
```

Publication, merge and deployment remain unauthorized.
