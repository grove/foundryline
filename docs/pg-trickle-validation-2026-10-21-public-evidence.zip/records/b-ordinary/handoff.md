# b-ordinary delivery handoff

Issue #1177. One ordinary local delivery attempt, clean detached baseline `0cbd84dce4fede39fa36f2c8716e0faa0a9b1b14`.
UTC start: 2026-10-21 16:32:30 (first recorded clock; first tool action immediately precedes it).
UTC end: 2026-10-21T16:42:32.314198+00:00.

Implemented the missing schema USAGE grant in shared `ensure_payload`, using the existing quoted consumer-owner role and SPI error handling. Existing SELECT remains scoped to the typed payload table. Added SQL reference documentation and one end-to-end regression in the existing v108 conformance suite.

Requirements/negative cases exercised: fresh ordinary NOSUPERUSER stream-table owner starts without change-schema USAGE; only public API EXECUTE and ordinary source SELECT/MAINTAIN privileges are granted; owner reads contract, registers consumer, completes resnapshot activation, obtains exact batch metadata and reads its typed INSERT/id/value payload. Selecting the actual stable-named source CDC buffer and private consumer catalog each fails with PostgreSQL 42501 after registration. No blanket SELECT, PUBLIC grant, schema CREATE grant, catalog grant or dependency was added.

Verification: `just fmt` passed. Final `just lint` passed with zero warnings (record 19; includes all-target Clippy and security/privilege/docs/SQL-builder/fuzz/monitoring checks). Source-built Docker E2E image passed (records 07/13); isolated image `pg_trickle_b_ordinary_1177:local`, identity `sha256:99859de61233a39404b8b86cb7dd93b7739e404dcf1f0550a34fc9e3dc3a218c linux/amd64`. Relevant E2E regression passed: 1 passed, 19 filtered out, exit 0 (record 20). `git diff --check` passed during review and final verification.

All named verification commands retain full combined stdout/stderr in `.log` files and exact command/cwd/start/end/duration/exit in matching `.json` files. Initial read-only source/instruction commands and edits are in the agent tool transcript; see `attempt-context.json` for scope and interventions. Preserved initial Python 3.9 build-generator failure, Docker socket denial, canceled builder rebuild/default-image run, and stale graph-digest fixture failure. Installed Homebrew Python resolved generator failure; fresh graph digest resolved fixture failure. No counterpart material or sibling files were read. One process query incidentally listed sibling compiler command lines; no fixes/source/results were accessed or used.

Final patch: `final.patch`, SHA256 `851fbc05434bfe247c55133e2957e7c594254cee8b41bf40cc14629ad3d5db13`. `final-state.json` includes per-file SHA256 and untracked file manifest (0 untracked files); actual Git index untouched. Candidate source writes stopped before this handoff. No commits, branches, pushes, PRs, remote changes or workflow runs.

Not run: full E2E/unit/integration suites, upgrade tests, baseline red build. Existing consumers receive schema USAGE when registration runs again; no retrospective role backfill or revocation lifecycle change was requested or added.

Suggested commands only (not executed):
```sh
git add src/api/output_delta.rs tests/e2e_v108_conformance_tests.rs docs/SQL_REFERENCE.md
git commit -m "fix: grant output-delta consumer schema usage"
```
