import json,os,pathlib,platform,subprocess,sys,time
root=pathlib.Path('/private/tmp/foundryline-21'); out=root/'local'; out.mkdir()
binpath=root/'bin';binpath.mkdir()
(binpath/'codex').symlink_to('/private/tmp/foundryline-18/runtime/node_modules/@openai/codex-darwin-arm64/vendor/aarch64-apple-darwin/bin/codex')
env=dict(os.environ,PATH=str(binpath)+os.pathsep+os.environ['PATH'])
python='/opt/homebrew/Cellar/python@3.14/3.14.8_2/Frameworks/Python.framework/Versions/3.14/bin/python3.14'
selected=[python,'-B','-m','unittest','discover','-s','checks','-p','test_intentline_trace.py','-k','test_complete_source_and_citations','-v']
(out/'checks.json').write_text(json.dumps([selected],indent=2)+'\n')
(out/'links.json').write_text(json.dumps({'R1':[{'index':0,'argv':selected}]},indent=2)+'\n')
cmd=[python,'-B','/private/tmp/foundryline-18/tool/proofline.py','check','--repo','/Users/grove/projects/foundryline','--source',str(root/'export/source-S1.txt'),'--intentline-export',str(root/'export'),'--intentline-links',str(out/'links.json'),'--checks',str(out/'checks.json'),'--seconds','180','--check-seconds','30','--output',str(out/'record')]
(out/'argv.json').write_text(json.dumps({'argv':cmd,'cwd':'/private/tmp/foundryline-18/tool','PATH':env['PATH']},indent=2)+'\n')
identity={'host':platform.platform(),'python':subprocess.check_output([python,'--version'],text=True).strip(),'codex':subprocess.check_output([str(binpath/'codex'),'--version'],env=env,text=True).strip(),'candidate_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'candidate_tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip()}
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
p=subprocess.run(cmd,cwd='/private/tmp/foundryline-18/tool',env=env,capture_output=True)
(out/'stdout.txt').write_bytes(p.stdout);(out/'stderr.txt').write_bytes(p.stderr);(out/'exit.txt').write_text(str(p.returncode)+'\n')
print('exit',p.returncode,p.stdout.decode()[-4000:],p.stderr.decode()[-3000:])
