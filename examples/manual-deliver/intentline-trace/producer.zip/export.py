import json, os, pathlib, subprocess, sys, shutil
root=pathlib.Path('/private/tmp/foundryline-21')
cmd=[sys.executable,'-B','-m','intentline','export','--work',str(root/'work'),'--format','json','--out',str(root/'export'),'--json']
env=dict(os.environ,PYTHONPATH='/Users/grove/projects/intentline')
p=subprocess.run(cmd,env=env,capture_output=True)
(root/'export.argv.json').write_text(json.dumps({'argv':cmd,'cwd':os.getcwd(),'PYTHONPATH':env['PYTHONPATH']},indent=2)+'\n')
(root/'export.stdout').write_bytes(p.stdout); (root/'export.stderr').write_bytes(p.stderr); (root/'export.exit').write_text(str(p.returncode)+'\n')
print(p.stdout.decode(),p.stderr.decode()); assert p.returncode==0
example=pathlib.Path('/Users/grove/projects/foundryline/examples/manual-deliver/intentline-trace')
example.mkdir()
shutil.copytree(root/'export',example/'export')
for name in ('issue-21.json','authorization.txt'):
    shutil.copyfile(root/name,example/name)
