import hashlib, json, os, pathlib, subprocess, sys
root = pathlib.Path('/private/tmp/foundryline-21')
issue = json.loads(pathlib.Path('/private/tmp/foundryline-21-issue.json').read_bytes())
(root/'issue-21.json').write_bytes(pathlib.Path('/private/tmp/foundryline-21-issue.json').read_bytes())
(root/'source-S1.txt').write_bytes(issue['body'].encode('utf-8'))
(root/'authorization.txt').write_text('Implement https://github.com/grove/foundryline/issues/21\nCreate PR\n')
env = dict(os.environ, PYTHONPATH='/Users/grove/projects/intentline')
cmd = [sys.executable, '-B', '-m', 'intentline', 'prepare', '--source', str(root/'source-S1.txt'), '--root', str(root), '--out', str(root/'work'), '--json']
p = subprocess.run(cmd, env=env, capture_output=True)
(root/'prepare.stdout').write_bytes(p.stdout)
(root/'prepare.stderr').write_bytes(p.stderr)
(root/'prepare.exit').write_text(str(p.returncode)+'\n')
(root/'prepare.argv.json').write_text(json.dumps({'argv':cmd,'cwd':os.getcwd(),'PYTHONPATH':env['PYTHONPATH']},indent=2)+'\n')
print(p.stdout.decode()); print(p.stderr.decode()); assert p.returncode == 0
