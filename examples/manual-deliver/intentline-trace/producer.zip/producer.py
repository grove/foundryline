import json, os, pathlib, subprocess, sys
root=pathlib.Path('/private/tmp/foundryline-21')
env=dict(os.environ,PYTHONPATH='/Users/grove/projects/intentline')
for name,args in [('propose',['--draft',str(root/'draft.json')]),('check',[]),('review',[]),('render',[])]:
    cmd=[sys.executable,'-B','-m','intentline',name,'--work',str(root/'work'),*args,'--json']
    p=subprocess.run(cmd,env=env,capture_output=True)
    (root/(name+'.argv.json')).write_text(json.dumps({'argv':cmd,'cwd':os.getcwd(),'PYTHONPATH':env['PYTHONPATH']},indent=2)+'\n')
    (root/(name+'.stdout')).write_bytes(p.stdout); (root/(name+'.stderr')).write_bytes(p.stderr); (root/(name+'.exit')).write_text(str(p.returncode)+'\n')
    print(name,p.returncode,p.stdout.decode()[:1300],p.stderr.decode()); assert p.returncode==0
