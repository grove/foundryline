import hashlib,json,pathlib,platform,subprocess,sys,zipfile
root=pathlib.Path('/private/tmp/foundryline-21')
example=pathlib.Path('/Users/grove/projects/foundryline/examples/manual-deliver/intentline-trace')
identity={'intentline_commit':subprocess.check_output(['git','-C','/Users/grove/projects/intentline','rev-parse','HEAD'],text=True).strip(),'proofline_commit':subprocess.check_output(['git','-C','/private/tmp/foundryline-18/tool','rev-parse','HEAD'],text=True).strip(),'tracked_tool_changes':'none (git diff and cached diff checked)','host':platform.platform(),'python':sys.version,'coding_agent':'Active user-authorized OpenAI Codex session; exact model build/accounting not exposed','authorization':'authorization.txt transcribed from the literal displayed user instruction; not authenticated authorship or contract adoption','source_capture':'GitHub CLI JSON body decoded and encoded UTF-8 without newline normalization/addition; full body, zero comments','starting_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()}
(root/'producer-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
files=[]
for p in root.iterdir():
    if p.is_file(): files.append(p)
files.extend(p for p in (root/'work').rglob('*') if p.is_file())
files.extend(p for p in (root/'export').rglob('*') if p.is_file())
with zipfile.ZipFile(example/'producer.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(files): z.write(p,p.relative_to(root).as_posix())
print('producer.zip',hashlib.sha256((example/'producer.zip').read_bytes()).hexdigest())
