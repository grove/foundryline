# Separately started review of first candidate

Reviewer: /root/independent_review, fresh context; same operator, provider and host. Not human approval.
Candidate: 51dad2bcf5b4b838fd81fa6385679220b14c4f2e, tree 79075a43934988eccb019cd0384078be7db02b08.

Must fix (P2): audit.mjs launches cli.ts using --experimental-strip-types, which emits an ExperimentalWarning on supported Node 22.16/22.17. The R1 test asserts empty stderr; official Node history says this warning ceased in 22.18. Reviewer inferred this from source and official documentation, without executing 22.16. Verify minimum runtime and narrowly handle the warning.
Source: https://nodejs.org/docs/latest-v22.x/api/typescript.html

No other product defect found. Original issue bytes equal exported S1, all export hashes/citations validate, report/evidence hashes and all 60 copied candidate-file hashes validate. Both native records correctly report EXECUTION UNAVAILABLE with preflight exit71; no product checks executed. First R2 NOT DEMONSTRATED, both linked CHECK UNAVAILABLE; coverage UNKNOWN. Negative mapping genuinely refused. Ordinary Node26 checks passed: 67 tests, format, lint, release and both self-audits.

Not checked: minimum Node runtime execution, working native isolation, publication or CI.
